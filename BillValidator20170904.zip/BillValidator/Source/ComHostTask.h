#ifndef __COMHOST_TASK__
#define	__COMHOST_TASK__

#include <RTL.h> 
//#include "lpc12xx.h"
#include "lpc12xx_libcfg_default.h"

__task void tsk_ComHost(void);

#endif
