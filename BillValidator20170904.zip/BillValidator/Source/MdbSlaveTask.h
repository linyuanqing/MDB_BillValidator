#ifndef __MDBSLAVE_TASK__
#define __MDBSLAVE_TASK__

#include <RTL.h> 
//#include "lpc12xx.h"
#include "lpc12xx_libcfg_default.h"

__task void tsk_MdbSlave(void);


#endif
