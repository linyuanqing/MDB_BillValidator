#ifndef __LED_TASK__
#define __LED_TASK__

//#include "lpc12xx.h"
#include "lpc12xx_libcfg_default.h"
#include <RTL.h> 

__task void tsk_Led(void);

#endif
